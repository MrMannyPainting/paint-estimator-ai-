
from flask import Flask, render_template, request, send_file
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from bs4 import BeautifulSoup
from fpdf import FPDF
import time

app = Flask(__name__)

def extract_property_data(address):
    options = Options()
    options.add_argument("--headless")
    driver = webdriver.Chrome(options=options)

    try:
        driver.get("https://www.assess.co.polk.ia.us/")
        search_box = driver.find_element(By.ID, "ctl00_cphBody_txtSearch")
        search_box.send_keys(address)
        search_button = driver.find_element(By.ID, "ctl00_cphBody_btnSearch")
        search_button.click()
        time.sleep(3)

        result_link = driver.find_element(By.XPATH, "//table[@id='ctl00_cphBody_gvSearchResults']//a")
        result_link.click()
        time.sleep(3)

        soup = BeautifulSoup(driver.page_source, "html.parser")

        def extract_text(label):
            cell = soup.find("td", string=label)
            return cell.find_next_sibling("td").get_text(strip=True) if cell else "N/A"

        data = {
            "Address": extract_text("Parcel Address:"),
            "Year Built": extract_text("Year Built:"),
            "Style": extract_text("Style:"),
            "Total Living Area": extract_text("Total Living Area:"),
            "Exterior Wall": extract_text("Exterior Wall:"),
            "Basement Area": extract_text("Basement Finish Area:"),
            "Lot Size": extract_text("Lot Size:")
        }

        return data

    finally:
        driver.quit()

def estimate_paint_requirements(data):
    try:
        living_area = int(data["Total Living Area"].replace(",", "").replace(" sq ft", ""))
    except:
        living_area = 1200

    try:
        lot_size = int(data["Lot Size"].replace(",", "").replace(" sq ft", ""))
    except:
        lot_size = 10000

    gallons_interior = round(living_area / 350)
    gallons_exterior = round(1800 / 250)

    price_interior = gallons_interior * 45 + 1000
    price_exterior = gallons_exterior * 55 + 1400

    return {
        "Interior Paint (gallons)": gallons_interior,
        "Exterior Paint (gallons)": gallons_exterior,
        "Estimated Interior Price": f"${price_interior}",
        "Estimated Exterior Price": f"${price_exterior}"
    }

def generate_full_report(data, estimate, filename):
    class PDF(FPDF):
        def header(self):
            self.set_font("Arial", "B", 14)
            self.cell(0, 10, "Property & Paint Estimate Report", ln=True, align="C")

        def footer(self):
            self.set_y(-15)
            self.set_font("Arial", "I", 8)
            self.cell(0, 10, f"Page {self.page_no()}", align="C")

    pdf = PDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)

    pdf.cell(0, 10, "Property Details:", ln=True)
    for key, value in data.items():
        pdf.cell(0, 10, f"{key}: {value}", ln=True)

    pdf.ln(5)
    pdf.set_font("Arial", "B", 12)
    pdf.cell(0, 10, "Paint Estimate:", ln=True)
    pdf.set_font("Arial", size=12)
    for key, value in estimate.items():
        pdf.cell(0, 10, f"{key}: {value}", ln=True)

    pdf.output(filename)

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        address = request.form["address"]
        data = extract_property_data(address)
        estimate = estimate_paint_requirements(data)
        filename = f"Report_{address.replace(' ', '_').replace(',', '')}.pdf"
        generate_full_report(data, estimate, filename)
        return send_file(filename, as_attachment=True)
    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)
